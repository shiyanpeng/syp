//
//  AppDelegate.h
//  YP
//
//  Created by syp on 15/10/10.
//  Copyright (c) 2015年 syp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

